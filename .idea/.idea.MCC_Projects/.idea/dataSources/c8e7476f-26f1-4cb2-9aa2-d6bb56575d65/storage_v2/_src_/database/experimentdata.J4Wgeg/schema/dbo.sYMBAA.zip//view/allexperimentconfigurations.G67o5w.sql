
CREATE VIEW [dbo].[AllExperimentConfigurations]
AS
SELECT 
	expconfig.ExperimentConfigurationID
	,expconfig.MaxDistanceToTarget
	,expconfig.MaxEvaluations
	,expconfig.MaxGenerations
	,expconfig.MaxRestarts
	,expconfig.NumSeedAgentGenomes
	,expconfig.NumSeedMazeGenomes
	,expconfig.MaxTimesteps
	,expconfig.MinSuccessDistance
	,expconfig.SerializeGenomeToXml
	,expconfig.PopulationLoggingBatchInterval
	,expdomain.ExperimentDomainName
FROM ExperimentConfiguration expconfig
JOIN ExperimentDomain expdomain
	ON expdomain.ExperimentDomainID = expconfig.ExperimentDomain_FK
go

