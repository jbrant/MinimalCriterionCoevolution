

CREATE VIEW [dbo].[ExperimentGenerationComplexityAverages] AS
WITH PriorCalc AS
(
	SELECT
		dict.ExperimentDictionaryID
		,dict.ExperimentName
		,data.Run
		,SUM(data.ChampGenomeConnectionGeneCount) / COUNT(*) AS MeanBestComplexity
		,COUNT(*) AS TotalGenerations
	FROM NoveltyExperimentEvaluationData data
	JOIN ExperimentDictionary dict
		ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
	GROUP BY dict.ExperimentDictionaryID, dict.ExperimentName, data.Run
)
SELECT 
	ExperimentName
	,ExperimentDictionaryID
	,SUM(TotalGenerations) / COUNT(*) AS [Average Generations]
	,SUM(MeanBestComplexity) / COUNT(*) AS [Average Complexity]	
FROM PriorCalc data
GROUP BY ExperimentName, ExperimentDictionaryID;

go

