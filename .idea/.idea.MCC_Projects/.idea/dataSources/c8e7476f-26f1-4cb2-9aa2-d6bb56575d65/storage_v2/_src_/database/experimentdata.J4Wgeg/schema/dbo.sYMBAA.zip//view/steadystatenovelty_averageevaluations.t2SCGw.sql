CREATE VIEW SteadyStateNovelty_AverageEvaluations
AS
WITH MaxPerRunEvaluations AS (
	SELECT
		dict.ExperimentDictionaryID
		,dict.ExperimentName
		,data.Run
		,MAX(data.TotalEvaluations) AS RunEvaluations
	FROM NoveltyExperimentEvaluationData data
	JOIN ExperimentDictionary_vw dict
		ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
	GROUP BY dict.ExperimentDictionaryID, dict.ExperimentName, data.Run
)
SELECT
	ExperimentDictionaryID
	,ExperimentName
	,SUM(RunEvaluations) / COUNT(*) AS AverageEvaluations
FROM MaxPerRunEvaluations
GROUP BY ExperimentDictionaryID, ExperimentName
go

