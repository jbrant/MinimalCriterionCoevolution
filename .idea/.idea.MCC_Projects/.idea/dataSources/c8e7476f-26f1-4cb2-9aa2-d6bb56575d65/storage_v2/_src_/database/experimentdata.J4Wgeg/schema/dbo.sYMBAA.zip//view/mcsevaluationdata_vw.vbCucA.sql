







CREATE VIEW [dbo].[MCSEvaluationData_vw]
 
AS
SELECT
	dict.ExperimentName
	,data.Run
	,data.Generation
	,data.TotalEvaluations
	,run_phase.RunPhaseName
	,TotalEvaluations / (dict.MaxEvaluations + dict.Primary_OffspringBatchSize) AS RestartCount
	,data.PopulationSize AS CurrentPopulationSize
	,data.OffspringCount
	,data.ViableOffspringCount
	,data.MaxComplexity
	,data.MeanComplexity
	,data.EvaluationsPerSecond
	,data.ClosestGenomeID
	,data.ClosestGenomeConnectionGeneCount
	,data.ClosestGenomeNeuronGeneCount
	,data.ClosestGenomeTotalGeneCount
	,data.ClosestGenomeDistanceToTarget
	,data.ClosestGenomeEndPositionX
	,data.ClosestGenomeEndPositionY
	,data.ClosestGenomeXml
	,dict.ConfigurationFile
	,dict.MaxEvaluations
	,dict.MaxRestarts
	,dict.NumSeedAgentGenomes
	,dict.NumSeedMazeGenomes
	,dict.MaxTimesteps
	,dict.MinSuccessDistance
	,dict.MaxDistanceToTarget
	,dict.SerializeGenomeToXml
	,dict.ExperimentDomainName
	
	,dict.Initialization_PopulationSize
	,dict.Initialization_NumSpecies
	,dict.Initialization_ElitismProportion
	,dict.Initialization_SelectionProportion
	,dict.Initialization_AsexualProbability
	,dict.Initialization_CrossoverProbability
	,dict.Initialization_InterspeciesMatingProbability
	,dict.Initialization_MutateConnectionWeightsProbability
	,dict.Initialization_MutateAddNeuronProbability
	,dict.Initialization_MutateAddConnectionProbability
	,dict.Initialization_MutateDeleteConnectionProbability
	,dict.Initialization_ConnectionProportion
	,dict.Initialization_ConnectionWeightRange

	,dict.Primary_PopulationSize
	,dict.Primary_NumSpecies
	,dict.Primary_ElitismProportion
	,dict.Primary_SelectionProportion
	,dict.Primary_AsexualProbability
	,dict.Primary_CrossoverProbability
	,dict.Primary_InterspeciesMatingProbability
	,dict.Primary_MutateConnectionWeightsProbability
	,dict.Primary_MutateAddNeuronProbability
	,dict.Primary_MutateAddConnectionProbability
	,dict.Primary_MutateDeleteConnectionProbability
	,dict.Primary_ConnectionProportion
	,dict.Primary_ConnectionWeightRange

	,dict.Initialization_OffspringBatchSize
	,dict.Initialization_PopulationEvaluationFrequency
	,dict.Initialization_NicheCapacity
	,dict.Initialization_NicheGridDensity
	,dict.Initialization_ReproductionProportion
	,dict.Initialization_ComplexityRegulationStrategy
	,dict.Initialization_ComplexityThreshold
	,dict.Initialization_SelectionAlgorithmName

	,dict.Primary_OffspringBatchSize
	,dict.Primary_PopulationEvaluationFrequency
	,dict.Primary_NicheCapacity
	,dict.Primary_NicheGridDensity
	,dict.Primary_ReproductionProportion
	,dict.Primary_ComplexityRegulationStrategy
	,dict.Primary_ComplexityThreshold
	,dict.Primary_SelectionAlgorithmName

	,dict.Initialization_SearchAlgorithmName
	,dict.Initialization_BehaviorCharacterizationName
	,dict.Initialization_NoveltySearch_NearestNeighbors
	,dict.Initialization_NoveltySearch_ArchiveAdditionThreshold
	,dict.Initialization_NoveltySearch_ArchiveThresholdDecreaseMultiplier
	,dict.Initialization_NoveltySearch_ArchiveThresholdIncreaseMultiplier
	,dict.Initialization_NoveltySearch_MaxGenerationsWithArchiveAddition
	,dict.Initialization_NoveltySearch_MaxGenerationsWithoutArchiveAddition
	,dict.Initialization_MCS_MinimalCriteriaThreshold
	,dict.Initialization_MCS_MinimalCriteriaStartX
	,dict.Initialization_MCS_MinimalCriteriaStartY
	,dict.Initialization_MCS_MinimalCriteriaName
	,dict.Initialization_MCS_BridgingMagnitude
	,dict.Initialization_MCS_BridgingApplications

	,dict.Primary_SearchAlgorithmName
	,dict.Primary_BehaviorCharacterizationName
	,dict.Primary_NoveltySearch_NearestNeighbors
	,dict.Primary_NoveltySearch_ArchiveAdditionThreshold
	,dict.Primary_NoveltySearch_ArchiveThresholdDecreaseMultiplier
	,dict.Primary_NoveltySearch_ArchiveThresholdIncreaseMultiplier
	,dict.Primary_NoveltySearch_MaxGenerationsWithArchiveAddition
	,dict.Primary_NoveltySearch_MaxGenerationsWithoutArchiveAddition
	,dict.Primary_MCS_MinimalCriteriaThreshold
	,dict.Primary_MCS_MinimalCriteriaStartX
	,dict.Primary_MCS_MinimalCriteriaStartY
	,dict.Primary_MCS_MinimalCriteriaName
	,dict.Primary_MCS_BridgingMagnitude
	,dict.Primary_MCS_BridgingApplications
FROM dbo.MCSExperimentEvaluationData data
JOIN dbo.ExperimentDictionary_vw dict
	ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
JOIN dbo.RunPhase run_phase
	ON run_phase.RunPhaseID = data.RunPhase_FK
go

