

CREATE VIEW dbo.vw_CoevolutionMCSMazeExperimentGenomes
AS
    SELECT 
           ROW_NUMBER() OVER(ORDER BY ExperimentDictionaryID
                                    , Run
                                    , Generation
                                    , GenomeID ASC) AS RowNumber
         , *
    FROM dbo.CoevolutionMCSMazeExperimentGenomes;
go

