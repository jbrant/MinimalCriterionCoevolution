

CREATE VIEW dbo.vw_MCC_MazeGenerationStatistics
AS
    WITH MazeAttributes
         AS (SELECT 
                    mazepop.ExperimentDictionaryID
                  , mazepop.Run
                  , mazepop.Generation
                  , mgen.GenomeXml.value('count(/Root/Mazes/Maze/Walls/Wall)', 'int') AS NumWalls
                  , mgen.GenomeXml.value('count(/Root/Mazes/Maze/Paths/Path)', 'int') AS NumWaypoints
                  , mgen.GenomeXml.value('(/Root/Mazes/Maze/@height)[1]', 'int') AS MazeHeight
                  , mgen.GenomeXml.value('(/Root/Mazes/Maze/@width)[1]', 'int') AS MazeWidth
             FROM dbo.MCCExperimentExtantMazePopulation mazepop
                  JOIN dbo.MCCExperimentMazeGenomes mgen
                      ON mgen.ExperimentDictionaryID = mazepop.ExperimentDictionaryID
                         AND mgen.Run = mazepop.Run
                         AND mgen.GenomeID = mazepop.GenomeID)
         SELECT 
                ExperimentDictionaryID
              , Run
              , Generation
              , MIN(NumWalls) AS MinWalls
              , MAX(NumWalls) AS MaxWalls
              , AVG(CAST(NumWalls AS FLOAT)) AS MeanWalls
              , MIN(NumWaypoints) AS MinWaypoints
              , MAX(NumWaypoints) AS MaxWaypoints
              , AVG(CAST(NumWaypoints AS FLOAT)) AS MeanWaypoints
              , MIN(MazeHeight) AS MinHeight
              , MAX(MazeHeight) AS MaxHeight
              , AVG(CAST(MazeHeight AS FLOAT)) AS MeanHeight
              , MIN(MazeWidth) AS MinWidth
              , MAX(MazeWidth) AS MaxWidth
              , AVG(CAST(MazeWidth AS FLOAT)) AS MeanWidth
         FROM MazeAttributes
         GROUP BY 
                  ExperimentDictionaryID
                , Run
                , Generation;
go

