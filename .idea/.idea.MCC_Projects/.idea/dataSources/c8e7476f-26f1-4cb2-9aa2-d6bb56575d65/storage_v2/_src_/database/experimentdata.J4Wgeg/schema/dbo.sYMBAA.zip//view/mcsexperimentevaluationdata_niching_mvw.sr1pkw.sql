
CREATE VIEW [dbo].[MCSExperimentEvaluationData_Niching_mvw]
 
AS
SELECT
	data.ExperimentDictionaryID
	,data.Run
	,data.Generation
	,data.RunPhase_FK
	,data.PopulationSize
	,data.OffspringCount
	,data.MaxComplexity
	,data.MeanComplexity
	,data.TotalEvaluations
	,data.EvaluationsPerSecond
	,data.ClosestGenomeID
	,data.ClosestGenomeConnectionGeneCount
	,data.ClosestGenomeNeuronGeneCount
	,data.ClosestGenomeTotalGeneCount
	,data.ClosestGenomeDistanceToTarget
	,data.ClosestGenomeEndPositionX
	,data.ClosestGenomeEndPositionY
	,data.ClosestGenomeXml
FROM dbo.MCSExperimentEvaluationData data
JOIN dbo.ExperimentDictionary dict
	ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
WHERE dict.ExperimentName LIKE 'Queueing MCS with Niching%'
;

go

