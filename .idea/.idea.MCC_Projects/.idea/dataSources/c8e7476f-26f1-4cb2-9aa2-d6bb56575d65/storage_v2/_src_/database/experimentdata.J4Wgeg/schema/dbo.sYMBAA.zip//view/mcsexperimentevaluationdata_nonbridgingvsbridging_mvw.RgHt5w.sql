
CREATE VIEW [dbo].[MCSExperimentEvaluationData_NonBridgingVsBridging_mvw]
 
AS
SELECT
	data.ExperimentDictionaryID
	,data.Run
	,data.Generation
	,data.RunPhase_FK
	,data.PopulationSize
	,data.OffspringCount
	,data.MaxComplexity
	,data.MeanComplexity
	,data.TotalEvaluations
	,data.EvaluationsPerSecond
	,data.ClosestGenomeID
	,data.ClosestGenomeConnectionGeneCount
	,data.ClosestGenomeNeuronGeneCount
	,data.ClosestGenomeTotalGeneCount
	,data.ClosestGenomeDistanceToTarget
	,data.ClosestGenomeEndPositionX
	,data.ClosestGenomeEndPositionY
	,data.ClosestGenomeXml
FROM dbo.MCSExperimentEvaluationData data
JOIN dbo.ExperimentDictionary dict
	ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
WHERE dict.ExperimentName IN (
	'Queueing MCS 1',
	'Queueing MCS 2',
	'Queueing MCS 3',
	'Queueing MCS 4',
	'Queueing MCS 5',
	'Queueing MCS 6',
	'Queueing MCS 7'
) OR dict.ExperimentName LIKE 'Queueing MCS with Bridging%'
;

go

