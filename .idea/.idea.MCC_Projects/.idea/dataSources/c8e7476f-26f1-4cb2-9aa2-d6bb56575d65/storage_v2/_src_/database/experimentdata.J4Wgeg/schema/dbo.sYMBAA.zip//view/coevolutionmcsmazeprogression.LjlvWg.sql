
CREATE VIEW CoevolutionMCSMazeProgression
AS
SELECT
	dict.ExperimentDictionaryID
	,dict.ExperimentName
	,maze_data.Run
	,maze_data.Generation AS Batch
	,maze_data.TotalEvaluations
	,maze_data.PopulationSize
	,maze_data.ViableOffspringCount
	,maze_data.MinWalls
	,maze_data.MaxWalls
	,maze_data.MeanWalls
FROM CoevolutionMCSMazeExperimentEvaluationData maze_data
JOIN ExperimentDictionary dict
	ON dict.ExperimentDictionaryID = maze_data.ExperimentDictionaryID
go

