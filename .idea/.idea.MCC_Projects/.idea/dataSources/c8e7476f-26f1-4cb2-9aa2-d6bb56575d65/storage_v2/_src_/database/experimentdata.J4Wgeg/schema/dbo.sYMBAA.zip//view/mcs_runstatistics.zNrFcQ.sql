CREATE VIEW MCS_RunStatistics
AS
SELECT
	dict.ExperimentDictionaryID
	,dict.ExperimentName
	,data.Run		
	,MAX(data.TotalEvaluations) AS RunEvaluations
	,MAX(data.MeanComplexity) AS RunMeanComplexity
	,MAX(data.MaxComplexity) AS RunMaxComplexity
	,IIF(MIN(data.ClosestGenomeDistanceToTarget) <= 5, 1, 0) AS RunMazeSolved
FROM MCSExperimentEvaluationData data
JOIN ExperimentDictionary_vw dict
	ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
GROUP BY dict.ExperimentDictionaryID, dict.ExperimentName, data.Run
;
go

