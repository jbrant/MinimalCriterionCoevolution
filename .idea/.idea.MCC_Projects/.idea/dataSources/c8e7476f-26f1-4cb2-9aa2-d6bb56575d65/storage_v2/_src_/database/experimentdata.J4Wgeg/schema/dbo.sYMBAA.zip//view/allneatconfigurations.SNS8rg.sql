
CREATE VIEW [dbo].[AllNeatConfigurations]
AS
SELECT
	NeatConfigurationID
	,PopulationSize
	,NumSpecies
	,ElitismProportion
	,SelectionProportion
	,AsexualProbability
	,CrossoverProbability
	,InterspeciesMatingProbability
	,MutateConnectionWeightProbability
	,MutateAddNeuronProbability
	,MutateAddConnectionProbability
	,MutateDeleteConnectionProbability
	,ConnectionProportion
	,ConnectionWeightRange
	,SpecieSizeFixed
FROM NeatConfiguration
go

