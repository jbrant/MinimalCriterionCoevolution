

CREATE VIEW [dbo].[TrajectoryDiversityByExperimentNameBatch]
WITH VIEW_METADATA
AS
    SELECT
           dict.ExperimentDictionaryID
         , dict.ExperimentName
         , td.Generation AS Batch
         , AVG(td.InterMazeDiversityScore) AS InterMazeDiversityScore
         , AVG(td.IntraMazeDiversityScore) AS IntraMazeDiversityScore
         , AVG(td.GlobalDiversityScore) AS GlobalDiversityScore
    FROM dbo.MCCTrajectoryDiversity td
         JOIN dbo.ExperimentDictionary_vw dict
             ON dict.ExperimentDictionaryID = td.ExperimentDictionaryID
    GROUP BY
             dict.ExperimentDictionaryID
           , dict.ExperimentName
           , td.Generation;
go

