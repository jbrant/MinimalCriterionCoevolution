CREATE VIEW dbo.MaxBatchesPerExperimentRun
WITH SCHEMABINDING
AS
    SELECT
           navigator_exp_genomes.ExperimentDictionaryID
         , navigator_exp_genomes.Run
         , navigator_exp_genomes.RunPhase_FK
         , run_phase.RunPhaseName
         , COUNT_BIG(DISTINCT navigator_exp_genomes.Generation) AS NumBatches
    FROM dbo.CoevolutionMCSNavigatorExperimentGenomes navigator_exp_genomes
         JOIN dbo.RunPhase run_phase
             ON run_phase.RunPhaseID = navigator_exp_genomes.RunPhase_FK
    GROUP BY
             navigator_exp_genomes.ExperimentDictionaryID
           , navigator_exp_genomes.Run
           , navigator_exp_genomes.RunPhase_FK
           , run_phase.RunPhaseName;
go

