
CREATE VIEW [dbo].[AllSearchAlgorithmConfigurations]
AS
SELECT 
	nov_search_bridge.ExperimentSearchAlgorithmBridgeID
	,nov_search_type.SearchAlgorithmName
	,nov_behavior.BehaviorCharacterizationName
	,nov_conf.NearestNeighbors
	,nov_conf.ArchiveAdditionThreshold
	,nov_conf.ArchiveThresholdDecreaseMultiplier
	,nov_conf.ArchiveThresholdIncreaseMultiplier
	,nov_conf.MaxGenerationsWithArchiveAddition
	,nov_conf.MaxGenerationsWithoutArchiveAddition
	,ISNULL(nov_mc.MinimalCriteriaName, 'No MC') AS MinimalCriteriaName
	,nov_mc_conf.MinimalCriteriaThreshold
	,NULL AS SuccessMinimalCriteriaThreshold
	,NULL AS FailureMinimalCriteriaThreshold
	,NULL AS MinimalCriteriaUpdateInterval
	,NULL AS MaxCriteriaUpdateCyclesWithoutChange
	,NULL AS BridgingMagnitude
	,NULL AS BridgingApplications
	,nov_mc_conf.MinimalCriteriaStartX
	,nov_mc_conf.MinimalCriteriaStartY
FROM ExperimentSearchAlgorithmBridge nov_search_bridge
JOIN NoveltySearchConfiguration nov_conf
	ON nov_conf.NoveltySearchConfigurationID = nov_search_bridge.NoveltySearchConfiguration_FK
JOIN BehaviorCharacterization nov_behavior
	ON nov_behavior.BehaviorCharacterizationID = nov_conf.BehaviorCharacterization_FK
JOIN SearchAlgorithmConfiguration nov_algo_conf
	ON nov_algo_conf.SearchAlgorithmConfigurationID = nov_conf.SearchAlgorithmConfiguration_FK
JOIN SearchAlgorithmType nov_search_type
	ON nov_search_type.SearchAlgorithmTypeID = nov_algo_conf.SearchAlgorithmType_FK
LEFT JOIN MinimalCriteriaSearchConfiguration nov_mc_conf
	ON nov_mc_conf.MinimalCriteriaConfigurationID = nov_conf.MinimalCriteriaConfiguration_FK
LEFT JOIN MinimalCriteria nov_mc
	ON nov_mc.MinimalCriteriaTypeID = nov_mc_conf.MinimalCriteria_FK
UNION
SELECT
	mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
	,mcs_search_type.SearchAlgorithmName
	,mcs_behavior.BehaviorCharacterizationName
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,mcs_mc.MinimalCriteriaName
	,mcs_conf.MinimalCriteriaThreshold
	,NULL
	,NULL
	,NULL
	,NULL
	,mcs_conf.BridgingMagnitude
	,mcs_conf.BridgingApplications
	,mcs_conf.MinimalCriteriaStartX
	,mcs_conf.MinimalCriteriaStartY
FROM ExperimentSearchAlgorithmBridge mcs_search_bridge
JOIN MinimalCriteriaSearchConfiguration mcs_conf
	ON mcs_conf.MinimalCriteriaConfigurationID = mcs_search_bridge.MinimalCriteriaConfiguration_FK
JOIN MinimalCriteria mcs_mc
	ON mcs_mc.MinimalCriteriaTypeID = mcs_conf.MinimalCriteria_FK
JOIN BehaviorCharacterization mcs_behavior
	ON mcs_behavior.BehaviorCharacterizationID = mcs_conf.BehaviorCharacterization_FK
JOIN SearchAlgorithmConfiguration mcs_algo_conf
	ON mcs_algo_conf.SearchAlgorithmConfigurationID = mcs_conf.SearchAlgorithmConfiguration_FK
JOIN SearchAlgorithmType mcs_search_type
	ON mcs_search_type.SearchAlgorithmTypeID = mcs_algo_conf.SearchAlgorithmType_FK
UNION
SELECT
	dyn_mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
	,dyn_mcs_search_type.SearchAlgorithmName
	,dyn_mcs_behavior.BehaviorCharacterizationName
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,dyn_mcs_mc.MinimalCriteriaName
	,NULL
	,NULL
	,NULL
	,dyn_mcs_conf.MinimalCriteriaUpdateInterval
	,dyn_mcs_conf.MaxCriteriaUpdateCyclesWithoutChange
	,dyn_mcs_conf.BridgingMagnitude
	,dyn_mcs_conf.BridgingApplications
	,dyn_mcs_conf.MinimalCriteriaStartX
	,dyn_mcs_conf.MinimalCriteriaStartY
FROM ExperimentSearchAlgorithmBridge dyn_mcs_search_bridge
JOIN DynamicMinimalCriteriaSearchConfiguration dyn_mcs_conf
	ON dyn_mcs_conf.MinimalCriteriaConfigurationID = dyn_mcs_search_bridge.DynamicMinimalCriteriaConfiguration_FK
JOIN MinimalCriteria dyn_mcs_mc
	ON dyn_mcs_mc.MinimalCriteriaTypeID = dyn_mcs_conf.MinimalCriteria_FK
JOIN BehaviorCharacterization dyn_mcs_behavior
	ON dyn_mcs_behavior.BehaviorCharacterizationID = dyn_mcs_conf.BehaviorCharacterization_FK
JOIN SearchAlgorithmConfiguration dyn_mcs_algo_conf
	ON dyn_mcs_algo_conf.SearchAlgorithmConfigurationID = dyn_mcs_conf.SearchAlgorithmConfiguration_FK
JOIN SearchAlgorithmType dyn_mcs_search_type
	ON dyn_mcs_search_type.SearchAlgorithmTypeID = dyn_mcs_algo_conf.SearchAlgorithmType_FK
UNION
SELECT
	coevo_mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
	,coevo_mcs_search_type.SearchAlgorithmName
	,coevo_mcs_behavior.BehaviorCharacterizationName
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,coevo_mcs_mc.MinimalCriteriaName
	,NULL
	,coevo_mcs_conf.SuccessMinimalCriteriaThreshold
	,coevo_mcs_conf.FailureMinimalCriteriaThreshold
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
	,NULL
FROM ExperimentSearchAlgorithmBridge coevo_mcs_search_bridge
JOIN CoevolutionMinimalCriteriaSearchConfiguration coevo_mcs_conf
	ON coevo_mcs_conf.CoevolutionMinimalCriteriaSearchConfigurationID = coevo_mcs_search_bridge.CoevolutionMinimalCriteriaConfiguration_FK
JOIN MinimalCriteria coevo_mcs_mc
	ON coevo_mcs_mc.MinimalCriteriaTypeID = coevo_mcs_conf.MinimalCriteria_FK
JOIN BehaviorCharacterization coevo_mcs_behavior
	ON coevo_mcs_behavior.BehaviorCharacterizationID = coevo_mcs_conf.BehaviorCharacterization_FK
JOIN SearchAlgorithmConfiguration coevo_mcs_algo_conf
	ON coevo_mcs_algo_conf.SearchAlgorithmConfigurationID = coevo_mcs_conf.SearchAlgorithmConfiguration_FK
JOIN SearchAlgorithmType coevo_mcs_search_type
	ON coevo_mcs_search_type.SearchAlgorithmTypeID = coevo_mcs_algo_conf.SearchAlgorithmType_FK
go

