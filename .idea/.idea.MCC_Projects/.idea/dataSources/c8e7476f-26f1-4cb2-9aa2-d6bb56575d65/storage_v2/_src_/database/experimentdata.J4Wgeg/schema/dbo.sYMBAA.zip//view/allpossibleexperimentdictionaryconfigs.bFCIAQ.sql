









CREATE VIEW [dbo].[AllPossibleExperimentDictionaryConfigs] AS
SELECT
	ExperimentConfigurationID
	,MaxDistanceToTarget AS ExperimentConfiguration_MaxDistanceToTarget
	,MaxEvaluations AS ExperimentConfiguration_MaxEvaluations
	,MaxGenerations AS ExperimentConfiguration_MaxGenerations
	,MaxRestarts AS ExperimentConfiguration_MaxRestarts
	,NumSeedAgentGenomes AS ExperimentConfiguration_NumSeedAgentGenomes
	,NumSeedMazeGenomes AS ExperimentConfiguration_NumSeedMazeGenomes
	,MaxTimesteps AS ExperimentConfiguration_MaxTimesteps
	,MinSuccessDistance AS ExperimentConfiguration_MinSuccessDistance
	,SerializeGenomeToXml AS ExperimentConfiguration_SerializeGenomeToXml
	,PopulationLoggingBatchInterval AS ExperimentConfiguration_PopulationLoggingBatchInterval
	,ExperimentDomainName AS ExperimentConfiguration_ExperimentDomainName

	,NeatConfigurationID
	,neat_configuration.PopulationSize AS NeatConfiguration_PopulationSize
	,NumSpecies AS NeatConfiguration_NumSpecies
	,ElitismProportion AS NeatConfiguration_ElitismProportion
	,SelectionProportion AS NeatConfiguration_SelectionProportion
	,AsexualProbability AS NeatConfiguration_AsexualProbability
	,CrossoverProbability AS NeatConfiguration_CrossoverProbability
	,InterspeciesMatingProbability AS NeatConfiguration_InterspeciesMatingProbability
	,MutateConnectionWeightProbability AS NeatConfiguration_MutateConnectionWeightProbability
	,MutateAddNeuronProbability AS NeatConfiguration_MutateAddNeuronProbability
	,MutateAddConnectionProbability AS NeatConfiguration_MutateAddConnectionProbability
	,MutateDeleteConnectionProbability AS NeatConfiguration_MutateDeleteConnectionProbability
	,ConnectionProportion AS NeatConfiguration_ConnectionProportion
	,ConnectionWeightRange AS NeatConfiguration_ConnectionWeightRange
	,neat_configuration.SpecieSizeFixed AS NeatConfiguration_SpecieSizeFixed

	,MazeConfigurationID
	,maze_configuration.PopulationSize AS MazeConfiguration_PopulationSize
	,MutateWallLocationProbability AS MazeConfiguration_MutateWallLocationProbability
	,MutatePassageLocationProbability AS MazeConfiguration_MutatePassageLocationProbability
	,MutateAddWallProbability AS MazeConfiguration_MutateAddWallProbability
	,PerturbanceMagnitude AS MazeConfiguration_PerturbanceMagnitude
	,MazeHeight AS MazeConfiguration_MazeHeight
	,MazeWidth AS MazeConfiguration_MazeWidth
	,MazeScaleMultiplier AS MazeConfiguration_MazeScaleMultiplier
	,maze_configuration.SpecieSizeFixed AS MazeConfiguration_SpecieSizeFixed

	,ExperimentSelectionAlgorithmBridgeID AS ExperimentSelectionAlgorithmID
	,SelectionAlgorithmName AS ExperimentSelectionAlgorithm_SelectionAlgorithmName
	,ComplexityRegulationStrategy AS ExperimentSelectionAlgorithm_ComplexityRegulationStrategy
	,ComplexityThreshold AS ExperimentSelectionAlgorithm_ComplexityThreshold
	,OffspringBatchSize AS ExperimentSelectionAlgorithm_SteadyStateQueueingSelection_OffspringBatchSize
	,PopulationEvaluationFrequency AS ExperimentSelectionAlgorithm_SteadyStateSelection_PopulationEvaluationFrequency
	,NicheCapacity AS ExperimentSelectionAlgorithm_QueueingWithNichingSelection_NicheCapacity
	,NicheGridDensity AS ExperimentSelectionAlgorithm_QueueingWithNichingSelection_NicheGridDensity
	,ReproductionProportion AS ExperimentSelectionAlgorithm_QueueingWithNichingSelection_ReproductionProportion

	,ExperimentSearchAlgorithmBridgeID AS ExperimentSearchAlgorithmID
	,SearchAlgorithmName AS ExperimentSearchAlgorithm_AlgorithmName
	,BehaviorCharacterizationName AS ExperimentSearchAlgorithm_BehaviorCharacterizationName
	,NearestNeighbors AS ExperimentSearchAlgorithm_Novelty_NearestNeighbors
	,ArchiveAdditionThreshold AS ExperimentSearchAlgorithm_Novelty_ArchiveAdditionThreshold
	,ArchiveThresholdDecreaseMultiplier AS ExperimentSearchAlgorithm_Novelty_ArchiveThresholdDecreaseMultiplier
	,ArchiveThresholdIncreaseMultiplier AS ExperimentSearchAlgorithm_Novelty_ArchiveThresholdIncreaseMultiplier
	,MaxGenerationsWithArchiveAddition AS ExperimentSearchAlgorithm_Novelty_MaxGenerationsWithArchiveAddition
	,MaxGenerationsWithoutArchiveAddition AS ExperimentSearchAlgorithm_Novelty_MaxGenerationsWithoutArchiveAddition
	,MinimalCriteriaName AS ExperimentSearchAlgorithm_MC_MCS_MinimalCriteriaName
	,MinimalCriteriaThreshold AS ExperimentSearchAlgorithm_MCS_MinimalCriteriaThreshold
	,SuccessMinimalCriteriaThreshold AS ExperimentSearchAlgorithm_MCS_SuccessMinimalCriteriaThreshold
	,FailureMinimalCriteriaThreshold AS ExperimentSearchAlgorithm_MCS_FailureMinimalCriteriaThreshold
	,MinimalCriteriaUpdateInterval AS ExperimentSearchAlgorithm_MCS_MinimalCriteriaUpdateInterval
	,MaxCriteriaUpdateCyclesWithoutChange AS ExperimentSearchAlgorithm_MCS_MaxCriteriaUpdateCyclesWithoutChange
	,BridgingMagnitude AS ExperimentSearchAlgorithm_MCS_BridgingMagnitude
	,BridgingApplications AS ExperimentSearchAlgorithm_MCS_BridgingApplications
	,MinimalCriteriaStartX AS ExperimentSearchAlgorithm_MCS_MinimalCriteriaStartX
	,MinimalCriteriaStartY AS ExperimentSearchAlgorithm_MCS_MinimalCriteriaStartY
FROM (
	SELECT 
		expconfig.ExperimentConfigurationID
		,expconfig.MaxDistanceToTarget
		,expconfig.MaxEvaluations
		,expconfig.MaxGenerations
		,expconfig.MaxRestarts
		,expconfig.NumSeedAgentGenomes
		,expconfig.NumSeedMazeGenomes
		,expconfig.MaxTimesteps
		,expconfig.MinSuccessDistance
		,expconfig.SerializeGenomeToXml
		,expconfig.PopulationLoggingBatchInterval
		,expdomain.ExperimentDomainName
	FROM ExperimentConfiguration expconfig
	JOIN ExperimentDomain expdomain
		ON expdomain.ExperimentDomainID = expconfig.ExperimentDomain_FK
) experiment_configuration, 
(
	SELECT
		NeatConfigurationID
		,PopulationSize
		,NumSpecies
		,ElitismProportion
		,SelectionProportion
		,AsexualProbability
		,CrossoverProbability
		,InterspeciesMatingProbability
		,MutateConnectionWeightProbability
		,MutateAddNeuronProbability
		,MutateAddConnectionProbability
		,MutateDeleteConnectionProbability
		,ConnectionProportion
		,ConnectionWeightRange
		,SpecieSizeFixed
	FROM NeatConfiguration
) neat_configuration, 
(
	SELECT
		MazeConfigurationID
		,PopulationSize
		,MutateWallLocationProbability
		,MutatePassageLocationProbability
		,MutateAddWallProbability
		,PerturbanceMagnitude
		,MazeHeight
		,MazeWidth
		,MazeScaleMultiplier
		,SpecieSizeFixed
	FROM MazeConfiguration
) maze_configuration,
(
	SELECT
		selection_bridge.ExperimentSelectionAlgorithmBridgeID
		,steady_state.OffspringBatchSize
		,steady_state.PopulationEvaluationFrequency
		,NULL AS NicheCapacity
		,NULL AS NicheGridDensity
		,NULL AS ReproductionProportion
		,select_conf.ComplexityRegulationStrategy
		,select_conf.ComplexityThreshold
		,select_algo_type.SelectionAlgorithmName
	FROM ExperimentSelectionAlgorithmBridge selection_bridge
	JOIN SteadyStateSelectionAlgorithmConfiguration steady_state
		ON steady_state.SteadyStateAlgorithmConfigurationID = selection_bridge.SteadyStateSelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmConfiguration select_conf
		ON select_conf.SelectionAlgorithmConfigurationID = steady_state.SelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmType select_algo_type
		ON select_algo_type.SelectionAlgorithmTypeID = select_conf.SelectionAlgorithmType_FK
	UNION
	SELECT
		selection_bridge.ExperimentSelectionAlgorithmBridgeID
		,queueing.OffspringBatchSize
		,NULL
		,NULL
		,NULL
		,NULL
		,select_conf.ComplexityRegulationStrategy
		,select_conf.ComplexityThreshold
		,select_algo_type.SelectionAlgorithmName
	FROM ExperimentSelectionAlgorithmBridge selection_bridge
	JOIN QueueingSelectionAlgorithmConfiguration queueing
		ON queueing.QueueingAlgorithmConfigurationID = selection_bridge.QueueingSelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmConfiguration select_conf
		ON select_conf.SelectionAlgorithmConfigurationID = queueing.SelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmType select_algo_type
		ON select_algo_type.SelectionAlgorithmTypeID = select_conf.SelectionAlgorithmType_FK
	UNION
	SELECT
		selection_bridge.ExperimentSelectionAlgorithmBridgeID
		,NULL
		,NULL
		,queueing_niching.NicheCapacity
		,queueing_niching.NicheGridDensity
		,queueing_niching.ReproductionProportion
		,select_conf.ComplexityRegulationStrategy
		,select_conf.ComplexityThreshold
		,select_algo_type.SelectionAlgorithmName
	FROM ExperimentSelectionAlgorithmBridge selection_bridge
	JOIN QueueingWithNichingSelectionAlgorithmConfiguration queueing_niching
		ON queueing_niching.QueueingWithNichingAlgorithmConfigurationID = selection_bridge.QueueingWithNichingSelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmConfiguration select_conf
		ON select_conf.SelectionAlgorithmConfigurationID = queueing_niching.SelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmType select_algo_type
		ON select_algo_type.SelectionAlgorithmTypeID = select_conf.SelectionAlgorithmType_FK
	UNION
	SELECT
		selection_bridge.ExperimentSelectionAlgorithmBridgeID
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,select_conf.ComplexityRegulationStrategy
		,select_conf.ComplexityThreshold
		,select_algo_type.SelectionAlgorithmName
	FROM ExperimentSelectionAlgorithmBridge selection_bridge
	JOIN GenerationalSelectionAlgorithmConfiguration generational
		ON generational.GenerationalSelectionAlgorithmConfigurationID = selection_bridge.GenerationalSelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmConfiguration select_conf
		ON select_conf.SelectionAlgorithmConfigurationID = generational.SelectionAlgorithmConfiguration_FK
	JOIN SelectionAlgorithmType select_algo_type
		ON select_algo_type.SelectionAlgorithmTypeID = select_conf.SelectionAlgorithmType_FK
) selection_algorithm,
(
	SELECT 
		nov_search_bridge.ExperimentSearchAlgorithmBridgeID
		,nov_search_type.SearchAlgorithmName
		,nov_behavior.BehaviorCharacterizationName
		,nov_conf.NearestNeighbors
		,nov_conf.ArchiveAdditionThreshold
		,nov_conf.ArchiveThresholdDecreaseMultiplier
		,nov_conf.ArchiveThresholdIncreaseMultiplier
		,nov_conf.MaxGenerationsWithArchiveAddition
		,nov_conf.MaxGenerationsWithoutArchiveAddition
		,nov_mc.MinimalCriteriaName
		,nov_mc_conf.MinimalCriteriaThreshold
		,NULL AS SuccessMinimalCriteriaThreshold
		,NULL AS FailureMinimalCriteriaThreshold
		,NULL AS MinimalCriteriaUpdateInterval
		,NULL AS MaxCriteriaUpdateCyclesWithoutChange
		,NULL AS BridgingMagnitude
		,NULL AS BridgingApplications
		,nov_mc_conf.MinimalCriteriaStartX
		,nov_mc_conf.MinimalCriteriaStartY
	FROM ExperimentSearchAlgorithmBridge nov_search_bridge
	JOIN NoveltySearchConfiguration nov_conf
		ON nov_conf.NoveltySearchConfigurationID = nov_search_bridge.NoveltySearchConfiguration_FK
	JOIN BehaviorCharacterization nov_behavior
		ON nov_behavior.BehaviorCharacterizationID = nov_conf.BehaviorCharacterization_FK
	JOIN SearchAlgorithmConfiguration nov_algo_conf
		ON nov_algo_conf.SearchAlgorithmConfigurationID = nov_conf.SearchAlgorithmConfiguration_FK
	JOIN SearchAlgorithmType nov_search_type
		ON nov_search_type.SearchAlgorithmTypeID = nov_algo_conf.SearchAlgorithmType_FK
	LEFT JOIN MinimalCriteriaSearchConfiguration nov_mc_conf
		ON nov_mc_conf.MinimalCriteriaConfigurationID = nov_conf.MinimalCriteriaConfiguration_FK
	LEFT JOIN MinimalCriteria nov_mc
		ON nov_mc.MinimalCriteriaTypeID = nov_mc_conf.MinimalCriteria_FK
	UNION
	SELECT
		mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
		,mcs_search_type.SearchAlgorithmName
		,mcs_behavior.BehaviorCharacterizationName
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,mcs_mc.MinimalCriteriaName
		,mcs_conf.MinimalCriteriaThreshold
		,NULL
		,NULL
		,NULL
		,NULL
		,mcs_conf.BridgingMagnitude
		,mcs_conf.BridgingApplications
		,mcs_conf.MinimalCriteriaStartX
		,mcs_conf.MinimalCriteriaStartY
	FROM ExperimentSearchAlgorithmBridge mcs_search_bridge
	JOIN MinimalCriteriaSearchConfiguration mcs_conf
		ON mcs_conf.MinimalCriteriaConfigurationID = mcs_search_bridge.MinimalCriteriaConfiguration_FK
	JOIN MinimalCriteria mcs_mc
		ON mcs_mc.MinimalCriteriaTypeID = mcs_conf.MinimalCriteria_FK
	JOIN BehaviorCharacterization mcs_behavior
		ON mcs_behavior.BehaviorCharacterizationID = mcs_conf.BehaviorCharacterization_FK
	JOIN SearchAlgorithmConfiguration mcs_algo_conf
		ON mcs_algo_conf.SearchAlgorithmConfigurationID = mcs_conf.SearchAlgorithmConfiguration_FK
	JOIN SearchAlgorithmType mcs_search_type
		ON mcs_search_type.SearchAlgorithmTypeID = mcs_algo_conf.SearchAlgorithmType_FK
	UNION
	SELECT
		dyn_mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
		,dyn_mcs_search_type.SearchAlgorithmName
		,dyn_mcs_behavior.BehaviorCharacterizationName
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,dyn_mcs_mc.MinimalCriteriaName
		,NULL
		,NULL
		,NULL
		,dyn_mcs_conf.MinimalCriteriaUpdateInterval
		,dyn_mcs_conf.MaxCriteriaUpdateCyclesWithoutChange
		,dyn_mcs_conf.BridgingMagnitude
		,dyn_mcs_conf.BridgingApplications
		,dyn_mcs_conf.MinimalCriteriaStartX
		,dyn_mcs_conf.MinimalCriteriaStartY
	FROM ExperimentSearchAlgorithmBridge dyn_mcs_search_bridge
	JOIN DynamicMinimalCriteriaSearchConfiguration dyn_mcs_conf
		ON dyn_mcs_conf.MinimalCriteriaConfigurationID = dyn_mcs_search_bridge.DynamicMinimalCriteriaConfiguration_FK
	JOIN MinimalCriteria dyn_mcs_mc
		ON dyn_mcs_mc.MinimalCriteriaTypeID = dyn_mcs_conf.MinimalCriteria_FK
	JOIN BehaviorCharacterization dyn_mcs_behavior
		ON dyn_mcs_behavior.BehaviorCharacterizationID = dyn_mcs_conf.BehaviorCharacterization_FK
	JOIN SearchAlgorithmConfiguration dyn_mcs_algo_conf
		ON dyn_mcs_algo_conf.SearchAlgorithmConfigurationID = dyn_mcs_conf.SearchAlgorithmConfiguration_FK
	JOIN SearchAlgorithmType dyn_mcs_search_type
		ON dyn_mcs_search_type.SearchAlgorithmTypeID = dyn_mcs_algo_conf.SearchAlgorithmType_FK
	UNION
	SELECT
		coevo_mcs_search_bridge.ExperimentSearchAlgorithmBridgeID
		,coevo_mcs_search_type.SearchAlgorithmName
		,coevo_mcs_behavior.BehaviorCharacterizationName
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,coevo_mcs_mc.MinimalCriteriaName
		,NULL
		,coevo_mcs_conf.SuccessMinimalCriteriaThreshold
		,coevo_mcs_conf.FailureMinimalCriteriaThreshold
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
		,NULL
	FROM ExperimentSearchAlgorithmBridge coevo_mcs_search_bridge
	JOIN CoevolutionMinimalCriteriaSearchConfiguration coevo_mcs_conf
		ON coevo_mcs_conf.CoevolutionMinimalCriteriaSearchConfigurationID = coevo_mcs_search_bridge.CoevolutionMinimalCriteriaConfiguration_FK
	JOIN MinimalCriteria coevo_mcs_mc
		ON coevo_mcs_mc.MinimalCriteriaTypeID = coevo_mcs_conf.MinimalCriteria_FK
	JOIN BehaviorCharacterization coevo_mcs_behavior
		ON coevo_mcs_behavior.BehaviorCharacterizationID = coevo_mcs_conf.BehaviorCharacterization_FK
	JOIN SearchAlgorithmConfiguration coevo_mcs_algo_conf
		ON coevo_mcs_algo_conf.SearchAlgorithmConfigurationID = coevo_mcs_conf.SearchAlgorithmConfiguration_FK
	JOIN SearchAlgorithmType coevo_mcs_search_type
		ON coevo_mcs_search_type.SearchAlgorithmTypeID = coevo_mcs_algo_conf.SearchAlgorithmType_FK
) search_algorithm
go

