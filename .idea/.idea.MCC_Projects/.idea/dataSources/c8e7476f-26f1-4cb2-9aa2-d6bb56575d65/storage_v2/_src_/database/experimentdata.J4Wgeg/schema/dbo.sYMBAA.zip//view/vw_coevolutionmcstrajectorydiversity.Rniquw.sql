

CREATE VIEW dbo.vw_CoevolutionMCSTrajectoryDiversity
AS
    SELECT 
           ROW_NUMBER() OVER(ORDER BY ExperimentDictionaryID
                                    , Run
                                    , Generation ASC) AS RowNumber
         , *
    FROM dbo.CoevolutionMCSTrajectoryDiversity;
go

