




CREATE VIEW [dbo].[AllMazeConfigurations]
AS
SELECT
	MazeConfigurationID
	,PopulationSize
	,NumSpecies
	,MutateWallLocationProbability
	,MutatePassageLocationProbability
	,MutateAddWallProbability
	,PerturbanceMagnitude
	,MazeHeight
	,MazeWidth
	,MazeScaleMultiplier
	,MinimumWalls
	,SpecieSizeFixed
	,MutateExpandMazeProbability
	,MutateDeleteWallProbability
	,MutatePathWaypointLocationProbability
	,MutateAddPathWaypointProbability
	,VerticalWallBias
	,QuadrantHeight
	,QuadrantWidth
FROM MazeConfiguration
go

