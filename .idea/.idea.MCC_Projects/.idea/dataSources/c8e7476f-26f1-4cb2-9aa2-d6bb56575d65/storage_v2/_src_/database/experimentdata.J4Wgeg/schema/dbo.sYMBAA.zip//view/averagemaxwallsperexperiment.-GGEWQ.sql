CREATE VIEW dbo.AverageMaxWallsPerExperiment
AS
    WITH AverageMaxWallsPerRun
         AS (SELECT
                    dict.ExperimentName
                  , Run
                  , MAX(data.MaxWalls) AS MaxWalls
             FROM dbo.CoevolutionMCSMazeExperimentEvaluationData data
                  JOIN dbo.ExperimentDictionary dict
                      ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
             WHERE ExperimentName LIKE 'Coevolution MCS with Maze Initialization [1-9]'
                   OR ExperimentName LIKE 'Coevolution MCS with Maze Initialization 1[1-6]'
             GROUP BY
                      dict.ExperimentName
                    , Run)
         SELECT
                ExperimentName
              , AVG(MaxWalls) AS AverageMaxWalls
         FROM AverageMaxWallsPerRun
         GROUP BY
                  ExperimentName;
go

