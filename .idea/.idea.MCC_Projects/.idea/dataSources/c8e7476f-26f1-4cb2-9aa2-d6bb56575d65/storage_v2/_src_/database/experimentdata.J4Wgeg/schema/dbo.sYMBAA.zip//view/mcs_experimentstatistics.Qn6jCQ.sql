


CREATE VIEW [dbo].[MCS_ExperimentStatistics]
AS
WITH MaxPerRunStatistics AS (
	SELECT
		dict.ExperimentDictionaryID
		,dict.ExperimentName
		,data.Run		
		,MAX(data.TotalEvaluations) AS RunEvaluations
		,STDEV(data.TotalEvaluations) AS StdDev
		,MAX(data.MeanComplexity) AS RunMeanComplexity
		,MAX(data.MaxComplexity) AS RunMaxComplexity
		,IIF(MIN(data.ClosestGenomeDistanceToTarget) <= 5, 1, 0) AS RunMazeSolved
	FROM MCSExperimentEvaluationData data
	JOIN ExperimentDictionary_vw dict
		ON dict.ExperimentDictionaryID = data.ExperimentDictionaryID
	GROUP BY dict.ExperimentDictionaryID, dict.ExperimentName, data.Run
)
SELECT
	ExperimentDictionaryID
	,ExperimentName
	,SUM(RunEvaluations) / COUNT(*) AS AverageEvaluations
	,CONVERT(INT, SUM(StdDev)) / COUNT(*) AS AverageStandardDeviation
	,SUM(RunMeanComplexity) / COUNT(*) AS AverageMeanComplexity
	,SUM(RunMaxComplexity) / COUNT(*) AS AverageMaxComplexity
	,SUM(RunMazeSolved) AS SuccessfulRunCount
FROM MaxPerRunStatistics
GROUP BY ExperimentDictionaryID, ExperimentName;


go

